#ifndef PROTO_SMTP_H
#define PROTO_SMTP_H
#include "proto-banner1.h"

extern const struct ProtocolParserStream banner_smtp;

#endif
